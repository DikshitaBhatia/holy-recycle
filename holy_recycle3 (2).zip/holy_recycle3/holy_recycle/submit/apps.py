from django.apps import AppConfig


class SubmitConfig(AppConfig):
    name = 'submit'
